from django.shortcuts import render, render_to_response
from django.core.context_processors import request, csrf
from django.views.decorators.csrf import csrf_protect
from login.models import login_table
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.redirects.models import Redirect
from django.shortcuts import redirect
from django.contrib import messages
from django.db import connection
from django.core import serializers

def login(request):
    c = {}
    c.update(csrf(request))
    firstname = request.POST.get('firstname')
    lastname = request.POST.get('lastname')
    email = request.POST.get('email')
    username = request.POST.get('username')
    password = request.POST.get('password')
    gender = request.POST.get('test')
    phonenumber = request.POST.get('phone')
    country = request.POST.get('country')
    data = login_table(first_name=firstname,last_name=lastname, email=email, user_name=username, password=password, gender=gender, phone=phonenumber,country=country)
    data.save()
    return render_to_response('log.html',c)

def loglink(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('log.html', c)

def page2(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('form.html', c)

def home(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('content.html', c)

def login1(request):
    c = {}
    c.update(csrf(request))
    try:
        username = request.POST.get('user')
        password= request.POST.get('pass')
        u = login_table.objects.get(user_name=username)
        p = login_table.objects.get(password=password)
        if u and p:
            response = HttpResponseRedirect('/homepage/',c)
    except login_table.DoesNotExist:
        #response = render_to_response('failed.html',c)
        #request.flash['error'] = 'something wrong'
        #raise ValueError('username or password is invalid')
        #messages.add_message(request, messages.INFO, "username or password is invalid!")
        response =  HttpResponseRedirect('/')
        #response = render(request, 'log.html', {'message':'invalid username or password'})
      
    return response

def homepage(request):
    cursor = connection.cursor()
    #cursor.execute("update login_login_table set last_name='Pandi' where first_name='Surya'")
    cursor.execute("delete from login_login_table where first_name='Arun'")
    #row = cursor.fetchall()
    obj = login_table.objects.all()
    #d={}
    #obj_list = []
    #for i in row:
        #obj_list.append(i[1])
        #obj_list.append(i[2])
        #obj_list.append(i[3])
        #obj_list.append(i[4])
        #obj_list.append(i[5])
        #obj_list.append(i[6])
        #obj_list.append(i[7])
        #obj_list.append(i[8])
    #print obj_list
    return render_to_response('homepage.html',{'details':obj})
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
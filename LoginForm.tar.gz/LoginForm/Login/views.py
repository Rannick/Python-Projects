from django.shortcuts import render, render_to_response
from django.core.context_processors import request, csrf
from django.views.decorators.csrf import csrf_protect
from Login.models import Person
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.redirects.models import Redirect
from django.shortcuts import redirect
from django.contrib import messages
from mx.Tools.Tools import username


def indexlink(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('index.html', c)

def index2link(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('index2.html', c)

def index3link(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('index3.html', c)

def goform(request):
    c = {}
    c.update(csrf(request))
    firstname = request.POST.get('firstname')
    lastname = request.POST.get('lastname')
    username = request.POST.get('username')
    password = request.POST.get('password')
    email = request.POST.get('email')
    phonenumber = request.POST.get('phone')
    data = Person(first_name=firstname,last_name=lastname, user_name=username, password=password, email=email, phone=phonenumber)
    data.save()
    return render_to_response('index.html',c)

def gologin(request):
    c = {}
    c.update(csrf(request))
    try:
        username = request.POST.get('username')
        password= request.POST.get('password')
        u = Person.objects.get(user_name=username)
        p = Person.objects.get(password=password)
        if u and p:
            response = render(request, 'index3.html', {'message':'successfully logged into this website'})
    except Person.DoesNotExist:
        response =  HttpResponseRedirect('/')
        response = render(request, 'index3.html', {'message':'invalid username or password'})
         
    return response
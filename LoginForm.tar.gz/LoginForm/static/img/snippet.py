		<!-- login section -->
			<section class="about text-center" id="login">
				<div class="container">
					<div class="row">
						<h2>Login</h2>
						<h4>In computer security, logging in is the process by which an individual gains access to a computer system by identifying and authenticating themselves. The user credentials are typically some form of "username" and a matching "password" and these credentials themselves are sometimes referred to as a login.</h4>

					

						

						 <div class="login-page">
  							<div class="form">
    							<form class="login-form" action="/gologin/" method="post">
    							{% csrf_token %}
     								 <p class="log" name="log">Login</p>
      									<input type="text" name="username" placeholder="username" required autofocus="on" autocomplete="off"/>
      									<input type="password" name="password" placeholder="password" required/>
      									<button>login</button>
      								<p class="message">Not registered? <a href="#signup">Create account</a><br><br><a href="#home">Go Home</a></p>
    							</form>
  							</div>
						</div>
			</section><!-- end of login section -->
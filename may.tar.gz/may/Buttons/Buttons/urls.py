from django.conf.urls import patterns, include, url
from django.contrib import admin
from django.views.generic.base import TemplateView
admin.autodiscover()

urlpatterns = patterns('',
    url(r'^$', TemplateView.as_view(template_name="newindex.html")),
    url(r'newloginpage/$', 'page2.views.newloginpage'),
    url(r'formlink/$', 'page2.views.formlink'),
    url(r'newformpage/$', 'page2.views.newformpage'),
    url(r'loginlink/$', 'page2.views.loginlink'),
    url(r'^newcontentpage/$', 'page2.views.newcontentpage'),
    url(r'^deletelink/$', 'page2.views.deletelink'),
    url(r'^update/$', 'page2.views.update'),
    url(r'^updatelink/$', 'page2.views.updatelink'),
    url(r'^example/$', 'page2.views.example'),
)

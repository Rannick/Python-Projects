from django.shortcuts import render, render_to_response
from django.core.context_processors import request, csrf
from django.views.decorators.csrf import csrf_protect
from page2.models import Buttons
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.redirects.models import Redirect
from django.shortcuts import redirect
from django.contrib import messages
from django.db import connection
import json,urllib

# from django.utils import simplejson 

# def examplejson(request):
#     data = {"name": "Mark", "age": "22"}
#     return render_to_response("delete.html", {'data': simplejson.dumps(data),})    


# def fbview(request):
#     data = {'foo': 'bar', 'hello': 'world'}
#     return HttpResponse(json.dumps(data), content_type='application/json')


# def jjson(request):
#     data = urllib.urlopen("http://api.openweathermap.org/data/2.5/weather?q=Chennai&appid=99dde11dc3baaf555279d23297fdd2c4").read()
#     output = json.loads(data)
#     print (output)
#     return HttpResponse(json.dumps(output), content_type='application/json')

def example(request):
    data = urllib.urlopen("http://api.openweathermap.org/data/2.5/weather?q=Chennai&appid=99dde11dc3baaf555279d23297fdd2c4").read()
    print data
    return render_to_response('delete.html', {'details': data})


#     obj = json.dumps(data)
#     d = "Ranjith"
#     print d
#     print(d)
#     print(data)
#     print type(data)
#     print data
#     print(obj)
#     return render_to_response('delete.html',{'details':obj})
#     return HttpResponse(json.loads(data), content_type='application/json')
#     return HttpResponse(json.dumps(obj), content_type='application/json')
#     return render(request, 'delete.html',  {'objects': a['objects']})

def newformpage(request):
    c = {}
    c.update(csrf(request))
    firstname = request.POST.get('firstname')
    lastname = request.POST.get('lastname')
    email = request.POST.get('email')
    username = request.POST.get('username')
    password = request.POST.get('password')
    gender = request.POST.get('test')
    phonenumber = request.POST.get('phone')
    country = request.POST.get('country')
    data = Buttons(first_name=firstname,last_name=lastname, email=email, user_name=username, password=password, gender=gender, phone=phonenumber,country=country)
    data.save()
    return render_to_response('newindex.html',c)

def loginlink(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('newindex.html', c)

def formlink(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('newindex2.html', c)

def deletelink(request):
    id=request.GET.get('id')
    cursor = connection.cursor()
    query = "DELETE FROM page2_buttons WHERE id = '%s';" % id
    print(query)
    cursor.execute(query)
    obj = Buttons.objects.all()
    return render_to_response('newcontent.html',{'details':obj})  

def update(request):
    c={}
    c.update(csrf(request))
    id=request.POST.get('id')
    first_name = request.POST.get('first_name')
    last_name = request.POST.get('last_name')
    email = request.POST.get('email')
    user_name = request.POST.get('user_name')
    password = request.POST.get('password')
    phone =request.POST.get('phone')
    gender = request.POST.get('test')
    country = request.POST.get('country')
    Buttons.objects.filter(pk=id).update(first_name=first_name, last_name=last_name, email=email, user_name=user_name, password=password, phone=phone, gender=gender, country=country)
#    p.first_name = firstname
#    p.save()
    #cursor=connection.cursor()
    #cursor.execute("update page2_buttons set first_name=%s, last_name=%s, email=%s, user_name=%s, password=%s, phone=%s, gender=%s, country=%s where id=%s" [first_name,last_name,phone,gender,password,country,id])
#     data = Buttons(first_name=first_name,last_name=last_name,email=email, user_name=user_name, password=password, phone=phone, gender=gender, country=country)
#     data.save()
    return HttpResponseRedirect("/newcontentpage/")

def updatelink(request):
    c = {}
    c.update(csrf(request))
    id=request.GET.get('id')
    c['id'] = id
    cursor = connection.cursor()
    query = "SELECT * FROM page2_buttons WHERE id = '%s';" % id
    #print(query)
    cursor.execute(query)
    results = cursor.fetchall()
    for row in results:
        first_name = row[1]
        last_name = row[2]
        email = row[3]
        user_name = row[4]
        password = row[5]
        gender = row[6]
        phone = row[7]
        country = row[8]
    c['first_name'] = first_name
    c['last_name'] = last_name
    c['email'] = email
    c['user_name'] = user_name
    c['password'] = password
    c['gender'] = gender
    c['phone'] = phone
    c['country'] = country
   
    #obj = Login.objects.all()
    return render(request,'update.html',c)

def newloginpage(request):
    c = {}
    c.update(csrf(request))
    try:
        username = request.POST.get('user')
        password= request.POST.get('pass')
        u = Buttons.objects.get(user_name=username)
        p = Buttons.objects.get(password=password)
        if u and p:
            response = HttpResponseRedirect('/newcontentpage/',c)
    except Buttons.DoesNotExist:
        response =  HttpResponseRedirect('/')
        #response = render(request, 'index.html', {'message':'invalid username or password'})
          
    return response

def newcontentpage(request):
    c = {}
    c.update(csrf(request))
    #cursor = connection.cursor()
    #cursor.execute("update login_login_table set last_name='Pandi' where first_name='Surya'")
    #cursor.execute("delete from login_login_table where first_name='Arun'")
    #cursor.execute("select * from login_login_table")
    #row = cursor.fetchall()
    obj = Buttons.objects.all()
    #d={}
    #obj_list = []
    #for i in row:
        #obj_list.append(i[1])
        #obj_list.append(i[2])
        #obj_list.append(i[3])
        #obj_list.append(i[4])
        #obj_list.append(i[5])
        #obj_list.append(i[6])
        #obj_list.append(i[7])
        #obj_list.append(i[8])
    #print obj_list
    return render_to_response('newcontent.html',{'details':obj})

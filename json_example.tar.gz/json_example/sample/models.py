from django.db import models

# Create your models here.
class jsondb(models.Model):
    country_name = models.CharField(max_length=30)
    longitudes = models.FloatField(max_length=20)
    latitudes = models.FloatField(max_length=20)
    
from django.shortcuts import render, render_to_response
from sample.models import jsondb
import json, urllib
from django.core.context_processors import request, csrf
from django.views.decorators.csrf import csrf_protect
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.redirects.models import Redirect
# Create your views here.
def page1(request):
    weather_info = urllib.urlopen("http://api.openweathermap.org/data/2.5/weather?q=Paris&appid=99dde11dc3baaf555279d23297fdd2c4").read()
    info = json.loads(weather_info)
    country_name = info["name"]
    coo_lon = info["coord"]["lon"]
    coo_lat = info["coord"]["lat"]
    data = jsondb(country_name = country_name, longitudes=coo_lon, latitudes=coo_lat)
    data.save()
    return render_to_response('index2.html', {'details': weather_info})

def page2(request):
    c = {}
    c.update(csrf(request))
    obj = jsondb.objects.all()
    return render_to_response('index3.html',{'details':obj})



# def valuepage(request):
#     c = {}
#     c.update(csrf(request))
#     country = request.POST.get('country')  
#     response = render_to_response(request, '/newvaluepage/',c)
#     return response
#     
# def newvaluepage(request):
# #     c = {}
# #     c.update(csrf(request))
#     name = request.POST.get('country')
#     weather_info = urllib.urlopen("http://api.openweathermap.org/data/2.5/weather?q="+name+"&appid=99dde11dc3baaf555279d23297fdd2c4").read()
# #     url="http://api.openweathermap.org/data/2.5/weather?q=&appid=99dde11dc3baaf555279d23297fdd2c4"
# #     weatherbot=urllib.urlopen(url)
# #     weatherinfo = json.load(weatherbot)
# #     print weatherinfo["coord"][0]["lon"]
# #     print weatherinfo["coord"][1]["lat"]
#     return render_to_response('index2.html', {'details': weather_info})
from django.conf.urls import patterns, include, url
from django.contrib import admin
from django.views.generic.base import TemplateView
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'json_example.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

#     url(r'^admin/', include(admin.site.urls)),
    url(r'^$', TemplateView.as_view(template_name="index.html")),
#     url(r'^$', 'sample.views.newvaluepage'),
    url(r'page1/$', 'sample.views.page1'),
    url(r'page2/$', 'sample.views.page2'),
    url(r'page3/$', 'sample.views.page3'),
)

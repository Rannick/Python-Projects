from django.shortcuts import render
from django.shortcuts import render, render_to_response
from django.core.context_processors import request, csrf
from django.views.decorators.csrf import csrf_protect
# Create your views here.
def index(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('index.html', c)

def about(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('about-us.html', c)

def products(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('products.html', c)

def contact(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('contact-us.html', c)

def single(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('single-post.html', c)

def login(request):
    c = {}
    c.update(csrf(request))
    return render_to_response('login.html', c)
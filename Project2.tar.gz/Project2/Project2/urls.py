from django.conf.urls import patterns, include, url
from django.views.generic.base import TemplateView
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'Project2.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    # url(r'^admin/', include(admin.site.urls)),
    url(r'^$', TemplateView.as_view(template_name="index.html")),
    url(r'index/$', 'module2.views.index'),
    url(r'about/$', 'module2.views.about'),
    url(r'products/$', 'module2.views.products'),
    url(r'contact/$', 'module2.views.contact'),
    url(r'single/$', 'module2.views.single'),
    url(r'login/$', 'module2.views.login'),
)
